CREATE DATABASE messages;

USE messages;

CREATE TABLE message (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  body TEXT,
  timestamp DATETIME
);


